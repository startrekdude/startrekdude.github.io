from collections import namedtuple
from ctypes import create_string_buffer, c_void_p, windll
from ctypes.wintypes import BOOL, DWORD, HANDLE, WORD
from functools import partial
from struct import unpack

__all__ = ("Colors", "fg", "bg", "reset")

Color = namedtuple("Color", ("fg", "bg"))
C = Color
Colors = namedtuple("Colors", ("Black", "Grey", "LightGrey", "White", "Blue", "Green", "Cyan", "Red", "Purple", "LightBlue", "LightGreen", "LightCyan",
	"LightRed", "LightPurple", "Yellow", "LightYellow"))(C(0,0), C(8,128), C(7,112), C(15,240), C(1,16), C(2,32), C(3,48), C(4,64), C(5,80), C(9,144),
	C(10,160), C(11,176), C(12,192), C(13,208), C(6,96), C(14,224))
del C

GetStdHandle = windll.kernel32.GetStdHandle
GetStdHandle.argtypes = (DWORD,)
GetStdHandle.restype = HANDLE

_GetConsoleScreenBufferInfo = windll.kernel32.GetConsoleScreenBufferInfo
_GetConsoleScreenBufferInfo.argtypes = (HANDLE, c_void_p)
_GetConsoleScreenBufferInfo.restype = BOOL

SetConsoleTextAttribute = windll.kernel32.SetConsoleTextAttribute
SetConsoleTextAttribute.argtypes = (HANDLE, WORD)
SetConsoleTextAttribute.restype = BOOL

STDOUT = GetStdHandle(-11)

def GetConsoleTextAttribute():
	info = create_string_buffer(22)
	_GetConsoleScreenBufferInfo(STDOUT, info)
	(bufx, bufy, curx, cury, wattr,
		left, top, right, bottom,
		maxx, maxy) = unpack("hhhhHhhhhhh", info.raw)
	del info
	return wattr
	
def setcolor(plane, color):
	if color not in Colors:
		raise ValueError("'color' must be a Color from Colors")
	color = getattr(color, plane)
	attr = GetConsoleTextAttribute()
	attr &= ~(getattr(Colors.White, plane))
	attr |= color
	SetConsoleTextAttribute(STDOUT, attr)

fg = partial(setcolor, "fg")
bg = partial(setcolor, "bg")

def reset():
	fg(Colors.LightGrey)
	bg(Colors.Black)